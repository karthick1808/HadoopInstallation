# Hadoop-Trainer
This is my hadoop trainer folder. It contains the instructions and source codes I use in the class.

This document is very abstract which means it is not strictly step-by-step guide. Please use it only when you understand what it does.

